"""Uploaded-video inspection: read frames, detect, analyse, write an annotated video.

To keep the app responsive, only every `frame_stride`-th frame goes through the
model; the frames in between are written with the latest overlay. A progress
callback lets the dashboard show a progress bar while frames are processed.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import cv2

from src.compliance.compliance_analyzer import ComplianceAnalyzer, ComplianceResult
from src.detection.annotate import draw_compliance
from src.detection.detector import PPEDetector
from src.events.event_manager import EventManager
from src.events.event_store import SafetyEvent
from src.utils.paths import load_settings

SUPPORTED_VIDEO_TYPES = ("mp4", "mov", "avi", "mkv", "m4v")


class InvalidVideoError(ValueError):
    pass


@dataclass
class VideoSummary:
    output_path: Path
    fps: float
    frames_total: int
    frames_read: int
    frames_processed: int
    seconds_elapsed: float
    person_detections: int = 0
    class_counts: dict[str, int] = field(default_factory=dict)
    worker_status_frames: dict[str, int] = field(default_factory=dict)
    events: list[SafetyEvent] = field(default_factory=list)
    suppressed_repeats: int = 0
    stopped_early: bool = False


def open_writer(path: Path, fps: float, size: tuple[int, int]) -> cv2.VideoWriter:
    """Prefer H.264 ('avc1') so browsers can play the file; fall back to mp4v."""
    for fourcc in ("avc1", "mp4v"):
        writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*fourcc), fps, size)
        if writer.isOpened():
            return writer
        writer.release()
    raise RuntimeError("Could not open a video writer (no avc1/mp4v support)")


def process_video(
    input_path: str | Path,
    output_path: str | Path,
    detector: PPEDetector,
    analyzer: ComplianceAnalyzer,
    event_manager: EventManager | None = None,
    frame_stride: int | None = None,
    max_frames: int | None = None,
    confidence: float | None = None,
    image_size: int | None = None,
    progress: Callable[[float, str], None] | None = None,
    should_stop: Callable[[], bool] | None = None,
) -> VideoSummary:
    cfg = load_settings()["video"]
    stride = max(1, int(frame_stride or cfg["frame_stride"]))
    limit = int(max_frames or cfg["max_frames"])
    input_path, output_path = Path(input_path), Path(output_path)

    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise InvalidVideoError("The video could not be opened (unsupported codec or corrupted file).")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    if fps <= 1 or fps > 240:
        fps = 25.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    ok, frame = cap.read()
    if not ok or frame is None:
        cap.release()
        raise InvalidVideoError("The video contains no readable frames.")

    h, w = frame.shape[:2]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    writer = open_writer(output_path, fps, (w, h))
    summary = VideoSummary(output_path, fps, total, 0, 0, 0.0)
    last_result: ComplianceResult | None = None
    start = time.time()
    index = 0
    try:
        while ok and frame is not None:
            if index >= limit:
                summary.stopped_early = True
                break
            if should_stop and should_stop():
                summary.stopped_early = True
                break
            if index % stride == 0:
                detections = detector.detect(frame, confidence=confidence, image_size=image_size)
                last_result = analyzer.analyze(detections)
                summary.frames_processed += 1
                for d in detections:
                    summary.class_counts[d.class_name] = summary.class_counts.get(d.class_name, 0) + 1
                summary.person_detections += len(last_result.workers)
                for worker in last_result.workers:
                    summary.worker_status_frames[worker.status] = summary.worker_status_frames.get(worker.status, 0) + 1
                annotated = draw_compliance(frame, last_result)
                if event_manager is not None:
                    media_t = index / fps
                    summary.events += event_manager.process(last_result, now=media_t, evidence_frame=annotated, media_time_s=media_t)
            else:
                annotated = draw_compliance(frame, last_result) if last_result else frame
            writer.write(annotated)
            index += 1
            summary.frames_read = index
            if progress and (index % 10 == 0):
                frac = min(1.0, index / total) if total else 0.0
                progress(frac, f"Frame {index}/{total or '?'} - {summary.frames_processed} analysed")
            ok, frame = cap.read()
    finally:
        cap.release()
        writer.release()
    summary.seconds_elapsed = round(time.time() - start, 2)
    if event_manager is not None:
        summary.suppressed_repeats = event_manager.suppressed
    if progress:
        progress(1.0, f"Done: {summary.frames_read} frames, {summary.frames_processed} analysed")
    return summary
