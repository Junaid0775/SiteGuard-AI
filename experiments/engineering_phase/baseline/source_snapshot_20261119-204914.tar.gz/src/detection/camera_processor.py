"""Live camera processing.

`LiveFrameProcessor` holds everything needed to analyse a stream of frames:
the detector, the compliance analyzer and an EventManager with cooldown. It is
used by the Streamlit WebRTC callback (browser webcam), and is independent of
where frames come from, so other sources can be added later.

`OpenCVFrameSource` is a small helper for non-browser sources (a local camera
index or, in future, an RTSP URL such as rtsp://user:pass@host/stream). It is
not needed for the browser webcam.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

import cv2
import numpy as np

from src.compliance.compliance_analyzer import ComplianceAnalyzer, ComplianceResult
from src.detection.annotate import draw_compliance
from src.detection.detector import PPEDetector
from src.events.event_manager import EventManager
from src.events.event_store import EventStore, SafetyEvent
from src.utils.paths import load_settings


@dataclass
class LiveStats:
    frames_received: int = 0
    frames_analysed: int = 0
    last_inference_ms: float = 0.0
    person_detections: int = 0
    class_counts: dict[str, int] = field(default_factory=dict)
    last_detections: list[dict] = field(default_factory=list)
    last_worker_rows: list[dict] = field(default_factory=list)
    recent_events: deque = field(default_factory=lambda: deque(maxlen=20))
    error: str | None = None
    started_at: float = field(default_factory=time.time)


class LiveFrameProcessor:
    def __init__(
        self,
        detector: PPEDetector,
        analyzer: ComplianceAnalyzer,
        store: EventStore | None,
        process_every_n: int | None = None,
        image_size: int | None = None,
        confidence: float | None = None,
        cooldown_seconds: float | None = None,
        source_name: str = "browser webcam",
    ) -> None:
        live_cfg = load_settings()["live"]
        self.detector = detector
        self.analyzer = analyzer
        self.every_n = max(1, int(process_every_n or live_cfg["process_every_n_frames"]))
        self.image_size = int(image_size or live_cfg["image_size"])
        self.confidence = confidence
        self.events = EventManager(store, "live_camera", source_name, cooldown_seconds=cooldown_seconds)
        self.stats = LiveStats()
        self._last_result: ComplianceResult | None = None
        self._lock = threading.Lock()

    def process(self, frame_bgr: np.ndarray) -> np.ndarray:
        """Analyse (every Nth) frame and return the annotated frame. Never raises."""
        with self._lock:
            self.stats.frames_received += 1
            n = self.stats.frames_received
        try:
            if n % self.every_n == 1 or self.every_n == 1:
                t0 = time.perf_counter()
                detections = self.detector.detect(frame_bgr, confidence=self.confidence, image_size=self.image_size)
                result = self.analyzer.analyze(detections)
                annotated = draw_compliance(frame_bgr, result)
                new_events = self.events.process(result, now=time.monotonic(), evidence_frame=annotated)
                with self._lock:
                    self._last_result = result
                    s = self.stats
                    s.frames_analysed += 1
                    s.last_inference_ms = (time.perf_counter() - t0) * 1000
                    s.person_detections += len(result.workers)
                    for d in detections:
                        s.class_counts[d.class_name] = s.class_counts.get(d.class_name, 0) + 1
                    s.last_detections = [{"Class": d.class_name, "Confidence": round(d.confidence, 2)} for d in detections]
                    s.last_worker_rows = result.table_rows()
                    for e in new_events:
                        s.recent_events.appendleft(e)
                    s.error = None
                return annotated
            with self._lock:
                last = self._last_result
            return draw_compliance(frame_bgr, last) if last else frame_bgr
        except Exception as exc:  # keep the video stream alive and report the problem
            with self._lock:
                self.stats.error = f"{type(exc).__name__}: {exc}"
            return frame_bgr

    def snapshot(self) -> dict:
        with self._lock:
            s = self.stats
            return {
                "frames_received": s.frames_received,
                "frames_analysed": s.frames_analysed,
                "last_inference_ms": round(s.last_inference_ms, 1),
                "person_detections": s.person_detections,
                "class_counts": dict(s.class_counts),
                "last_detections": list(s.last_detections),
                "last_worker_rows": list(s.last_worker_rows),
                "recent_events": list(s.recent_events),
                "error": s.error,
                "running_seconds": round(time.time() - s.started_at, 1),
            }


class OpenCVFrameSource:
    """Read frames from a local camera index or a stream URL (future RTSP support)."""

    def __init__(self, source: int | str = 0) -> None:
        self.source = source
        self.cap: cv2.VideoCapture | None = None

    def open(self) -> bool:
        self.cap = cv2.VideoCapture(self.source)
        return bool(self.cap.isOpened())

    def read(self) -> np.ndarray | None:
        if self.cap is None:
            return None
        ok, frame = self.cap.read()
        return frame if ok else None

    def close(self) -> None:
        if self.cap is not None:
            self.cap.release()
            self.cap = None


def recent_event_rows(events: list[SafetyEvent]) -> list[dict]:
    return [{"Time": e.timestamp, "Category": e.category, "Confidence": e.confidence, "Worker": e.worker_ref} for e in events]
